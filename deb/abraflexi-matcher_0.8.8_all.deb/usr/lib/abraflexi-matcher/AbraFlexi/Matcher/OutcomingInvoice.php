<?php

/**
 * Outcoming Invoice Matcher
 *
 * @author     Vítězslav Dvořák <vitex@arachne.cz>
 * @copyright (c) 2018, Vítězslav Dvořák
 */

namespace AbraFlexi\Matcher;

/**
 * Description of InvoicePayment
 *
 * @author vitex
 */
class OutcomingInvoice extends ParovacFaktur {
    
}
