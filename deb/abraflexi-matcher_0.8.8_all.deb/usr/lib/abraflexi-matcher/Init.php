<?php

use AbraFlexi\Stitek;
use Ease\Functions;
use Ease\Shared;

/**
 * php-abraflexi-matecher
 * 
 * @copyright (c) 2018-2021, Vítězslav Dvořák
 */
$autoloader = require_once '/var/lib/abraflexi-matcher/autoload.php';
$shared = Shared::singleton();
if (file_exists('/etc/abraflexi/matcher.env')) {
    $shared->loadConfig('/etc/abraflexi/matcher.env', true);
}
new \Ease\Locale($shared->getConfigValue('MATCHER_LOCALIZE'), '../i18n', 'abraflexi-matcher');

$labeler = new Stitek();
$labeler->logBanner(Functions::cfg('APP_NAME'));
$labeler->addStatusMessage(_('checking labels'), 'debug');

$updateCfg = false;
foreach (['PREPLATEK', 'CHYBIFAKTURA', 'NEIDENTIFIKOVANO'] as $label) {
    if (is_null($shared->getConfigValue('LABEL_' . $label))) {
        $shared->setConfigValue('LABEL_' . $label, $label);
        $labeler->addStatusMessage(sprintf(_('Cannot find LABEL_%s in config file /etc/abraflexi/matcher.env. Using default value: %s'),
                        $label, $label), 'warning');
        $updateCfg = true;
    }
    if ($labeler->recordExists(['kod' => $shared->getConfigValue('LABEL_' . $label)]) === false) {
        $labeler->createNew($shared->getConfigValue('LABEL_' . $label), ['banka']);
        $labeler->addStatusMessage(sprintf(_('LABEL_%s: %s was created in AbraFlexi'),
                        $label, $shared->getConfigValue('LABEL_' . $label)), 'success');
    } else {
        $labeler->addStatusMessage(sprintf(_('LABEL_%s: %s exists in AbraFlexi'),
                        $label, $shared->getConfigValue('LABEL_' . $label)));
    }
}

function cfg2env($config) {
    $env = [];
    foreach ($config as $key => $value) {
        $env[] = $key . '=' . $value . "\n";
    }
    return implode('',$env);
}

if ($updateCfg === true) {
    foreach ([
        "APP_NAME", 
        "EASE_MAILTO", 
        "EASE_LOGGER", 
        "MATCHER_LOCALIZE", 
        "MATCHER_PULL_BANK", 
        "MATCHER_DAYS_BACK", 
        "LABEL_PREPLATEK", 
        "LABEL_CHYBIFAKTURA", 
        "LABEL_NEIDENTIFIKOVANO"] as $cfg) {
        $cfg2save[$cfg] = $shared->getConfigValue($cfg);
    }
    if (file_put_contents('/etc/abraflexi/matcher.env', cfg2env($cfg2save))) {
        $labeler->addStatusMessage(_('/etc/abraflexi/matcher.env was updated'), 'success');
    } else {
        $labeler->addStatusMessage(_('../env was not updated', 'error'),
                'success');
    }
}
$labeler->addStatusMessage(_('labels check done'), 'debug');
