<?php

use Ease\Shared;

/**
 * abraflexi-pull-bank
 * 
 * @copyright (c) 2018-2020, Vítězslav Dvořák
 */
define('APP_NAME', 'StahniBanku');
require_once '/var/lib/abraflexi-matcher/autoload.php';
$shared = Shared::singleton();
if (file_exists('/etc/abraflexi/matcher.env')) {
    $shared->loadConfig('/etc/abraflexi/matcher.env', true);
}
new \Ease\Locale($shared->getConfigValue('MATCHER_LOCALIZE'), '../i18n', 'abraflexi-matcher');

$banker = new \AbraFlexi\Banka();
$banker->logBanner(constant('APP_NAME'));
$banker->addStatusMessage(_('Download online bank statements'), 'debug');
if (!$banker->stahnoutVypisyOnline()) {
    $banker->addStatusMessage('Bank Offline!', 'error');
}
    