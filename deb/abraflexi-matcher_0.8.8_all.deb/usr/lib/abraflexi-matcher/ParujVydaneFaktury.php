<?php

/**
 * php-abraflexi-matcher
 * 
 * @copyright (c) 2018-2020, Vítězslav Dvořák
 */
use Ease\Shared;
use AbraFlexi\Matcher\OutcomingInvoice;

define('APP_NAME', 'ParujVydaneFaktury');
require_once '/var/lib/abraflexi-matcher/autoload.php';
$shared = Shared::singleton();
if (file_exists('/etc/abraflexi/matcher.env')) {
    $shared->loadConfig('/etc/abraflexi/matcher.env', true);
}
new \Ease\Locale($shared->getConfigValue('MATCHER_LOCALIZE'), '../i18n', 'abraflexi-matcher');

$invoiceSteamer = new OutcomingInvoice($shared->configuration);
$invoiceSteamer->banker->logBanner(constant('APP_NAME'));

if ($shared->getConfigValue('PULL_BANK') === true) {
    $invoiceSteamer->addStatusMessage(_('pull account statements'), 'debug');
    if (!$invoiceSteamer->banker->stahnoutVypisyOnline()) {
        $invoiceSteamer->addStatusMessage('Banka Offline!', 'error');
    }
}

$invoiceSteamer->addStatusMessage(_('Outgoing Invoice matching begin'), 'debug');
$invoiceSteamer->outInvoicesMatchingByBank();
$invoiceSteamer->addStatusMessage(_('Outgoing Invoice matching done'), 'debug');
