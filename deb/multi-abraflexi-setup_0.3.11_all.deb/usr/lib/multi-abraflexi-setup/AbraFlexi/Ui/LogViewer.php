<?php

/**
 * Multi AbraFlexi Setup - 
 *
 * @author Vítězslav Dvořák <info@vitexsoftware.cz>
 * @copyright  2020 Vitex Software
 */

namespace AbraFlexi\MultiSetup\Ui;

/**
 * Description of LogViewer
 *
 * @author vitex
 */
class LogViewer {
    //put your code here
}
