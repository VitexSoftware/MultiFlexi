<?php
/**
 * Multi AbraFlexi Setup - Webhook acceptor.
 *
 * @author Vítězslav Dvořák <info@vitexsoftware.cz>
 * @copyright  2020 Vitex Software
 */

namespace AbraFlexi\MultiSetup\Ui;

require_once './init.php';

