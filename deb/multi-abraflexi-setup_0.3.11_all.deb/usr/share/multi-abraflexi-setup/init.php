<?php

/**
 * Multi AbraFlexi Setup - Company instance editor.
 *
 * @author Vítězslav Dvořák <info@vitexsoftware.cz>
 * @copyright  2020 Vitex Software
 */

namespace AbraFlexi\MultiSetup;

use Ease\Shared;
use AbraFlexi\MultiSetup\Ui\WebPage;

require_once '/var/lib/multi-abraflexi-setup/autoload.php';

session_start();

\Ease\Shared::singleton()->loadConfig("/usr/lib/multi-abraflexi-setup/" . '/.env', true);

\Ease\Locale::singleton(null,'/usr/share/locale','multiabraflexisetup');

define('EASE_LOGGER', 'syslog|\AbraFlexi\MultiSetup\LogToSQL');

$oUser = Shared::user(null, 'AbraFlexi\MultiSetup\User');
$oPage = new WebPage();
